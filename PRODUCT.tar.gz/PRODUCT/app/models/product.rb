class Product < ActiveRecord::Base
	validates :name, presence: true,allow_blank: false
	validates :material_code, uniqueness: true
	validates :product_category_code, presence: true,allow_blank: false
end
