class ProductsController < ApplicationController

	def import
		import_data = SmarterCSV.process("#{Rails.root}/db/product_details.csv")
		import_data.each do |data|
			product = Product.find_by(material_code: data[:material_code])
			if product.present?
				product.update(name: data.values[0], material_code: data.values[1], product_category_code: data.values[2], status: data.values[3])
			else
				Product.create(name: data.values[0], material_code: data.values[1], product_category_code: data.values[2], status: data.values[3])
			end
		end
		render json: {message: "imported successfully", status: 200}
	end

	def products_available
		product = Product.where(status: true)
		render json: {products: product}
	end

	def get_articles
		
		request = RestClient::Request.new({
                                            method: :get,
                                            url: "https://newsapi.org/v2/top-headlines?sources=google-news&apiKey=0a708bae59cd4f92b26a6bc4c114f1f0",
                                            headers: { "Accept" => "application/json", "Content-Type" => "application/json" }
                                        })
		begin
		response = request.execute
		articles = eval(response.body)[:articles]
		articles.each do |article|
			
			Article.create(source: article[:source], author: article[:author], title: article[:title], discription: article[:discription], url: article[:url], url_to_image: article[:url_to_image], published_at: article[:published_at], content: article[:content])
		end
		render json: {articles: articles, status:200}
	    rescue
	    	render json: {message: "Unable to get Articles", status: 404}
	    end
	end

end
