Rails.application.routes.draw do
  get 'products/import', :to => 'products#import'
  get 'products/products_available', :to => 'products#products_available'
  get 'articles/get_articles', :to => 'products#get_articles'
end
