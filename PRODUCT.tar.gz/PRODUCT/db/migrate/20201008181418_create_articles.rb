class CreateArticles < ActiveRecord::Migration
  def change
    enable_extension "hstore"
    create_table :articles do |t|
      t.hstore :source
      t.string :author
      t.string :title
      t.string :discription
      t.string :url
      t.string :url_to_image
      t.string :published_at
      t.string :content

      t.timestamps null: false
    end
  end
end
